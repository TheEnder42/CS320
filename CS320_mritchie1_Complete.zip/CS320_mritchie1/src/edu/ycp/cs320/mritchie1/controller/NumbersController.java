package edu.ycp.cs320.mritchie1.controller;

public class NumbersController {
		
	public Double add(Double first, Double second, Double third) {
		return first + second + third;
	}
	
	public Double multiply(Double first, Double second) {
		return first * second;
	}
}
