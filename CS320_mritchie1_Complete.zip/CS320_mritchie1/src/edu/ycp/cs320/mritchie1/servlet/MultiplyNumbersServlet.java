package edu.ycp.cs320.mritchie1.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ycp.cs320.mritchie1.controller.NumbersController;
import edu.ycp.cs320.mritchie1.model.Numbers;

public class MultiplyNumbersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.getRequestDispatcher("/_view/multiplyNumbers.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		Numbers model = new Numbers();
		// Decode form parameters and dispatch to controller
		String errorMessage = null;
		//Double result = null;
		try {
			model.setValue1(getDouble(req, "first"));
			model.setValue2(getDouble(req, "second"));

			if (model.getValue1().equals(null) || model.getValue2().equals(null)) {
				errorMessage = "Please specify two numbers";
			} else {
				NumbersController controller = new NumbersController();
				model.setResult(controller.multiply(model.getValue1(), model.getValue2()));
			}
		} catch (NumberFormatException e) {
			errorMessage = "Invalid double";
		}
		/*
		// Add parameters as request attributes
		req.setAttribute("first", req.getParameter("first"));
		req.setAttribute("second", req.getParameter("second"));
		*/
		// Add result objects as request attributes
		req.setAttribute("errorMessage", errorMessage);
		//req.setAttribute("result", result);
		req.setAttribute("game", model);
		// Forward to view to render the result HTML document
		req.getRequestDispatcher("/_view/multiplyNumbers.jsp").forward(req, resp);
	}
	
	private Double getDouble(HttpServletRequest req, String name) {
		return Double.parseDouble(req.getParameter(name));
	}
	
	private Double getDoubleFromParameter(String s) {
		if (s == null || s.equals("")) {
			return null;
		} else {
			return Double.parseDouble(s);
		}
	}
}
