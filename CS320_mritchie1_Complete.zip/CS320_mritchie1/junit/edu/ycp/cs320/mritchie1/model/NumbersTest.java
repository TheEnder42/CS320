package edu.ycp.cs320.mritchie1.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.mritchie1.model.GuessingGame;

public class NumbersTest {
	private Numbers model, model2;
	
	@Before
	public void setUp() {
		model = new Numbers();
		model2 = new Numbers();
		model2.setValue1(1.0);
		model2.setValue2(2.0);
		model2.setValue3(8.0);
		model2.setResult(32.0);
	}
	
	@Test
	public void testSet1() {
		model.setValue1(1.0);
		assertTrue(model.getValue1() != 0);
	}
	
	@Test
	public void testSet2() {
		model.setValue2(2.0);
		assertTrue(model.getValue2() != 0);
	}
	
	@Test
	public void testSet3() {
		model.setValue3(3.0);
		assertTrue(model.getValue3() != 0);
	}
	
	@Test
	public void testResult() {
		model.setResult(4.0);
		assertTrue(model.getResult() != 0);	
	}
	
	@Test
	public void testGet1() {
		assertTrue(model2.getValue1() == 1);
	}
	
	@Test
	public void testGet2() {
		assertTrue(model2.getValue2() == 2);
	}
	
	@Test
	public void testGet3() {
		assertTrue(model2.getValue3() == 8);
	}
	
	@Test
	public void testGetResult() {
		assertTrue(model2.getResult() == 32);
	}
}
