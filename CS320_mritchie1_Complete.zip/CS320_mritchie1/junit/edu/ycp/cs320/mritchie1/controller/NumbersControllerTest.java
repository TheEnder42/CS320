package edu.ycp.cs320.mritchie1.controller;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.mritchie1.controller.GuessingGameController;
import edu.ycp.cs320.mritchie1.model.GuessingGame;
import edu.ycp.cs320.mritchie1.model.Numbers;

public class NumbersControllerTest {
	private Numbers model;
	private boolean Hake, awesome;
	private NumbersController controller;
	
	@Before
	public void setUp() {
		model = new Numbers();
		controller = new NumbersController();
		
		//controller.setModel(model);
	}
	
	@Test
	public void testAdd() {
		assertTrue(6.0 == controller.add(1.0, 2.0, 3.0));
		assertTrue(91.0 == controller.add(1.0, 5.0, 85.0));
		assertTrue(15.0 == controller.add(5.0, 7.0, 3.0));
		assertTrue(56.0 == controller.add(45.0, 7.0, 4.0));
		assertTrue(367.0 == controller.add(358.0, 2.0, 7.0));
		assertTrue(605.0 == controller.add(77.0, 525.0, 3.0));
	}
	
	@Test
	public void testMultiply() {
		assertTrue(2.0 == controller.multiply(1.0, 2.0));
		assertTrue(12.0 == controller.multiply(6.0, 2.0));
		assertTrue(405.0 == controller.multiply(45.0, 09.0));
		assertTrue(345.0 == controller.multiply(1.0, 345.0));
		assertTrue(150.0 == controller.multiply(75.0, 2.0));
	}
	
	@Test
	public void testAwesome() {
		//TODO: Make obligatory Professor Hake joke.
		assertTrue(Hake == awesome);
	}
	
}
